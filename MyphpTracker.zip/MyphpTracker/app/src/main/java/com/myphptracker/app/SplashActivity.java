package com.myphptracker.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide action bar
        if (getActionBar() != null) {
            getActionBar().hide();
        }

        setContentView(R.layout.splash_screen);

        // Delay 2 seconds then open MainActivity
        new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					Intent intent = new Intent(SplashActivity.this, MainActivity.class);
					startActivity(intent);
					finish();
				}
			}, 2000); // 2000 milliseconds = 2 seconds
    }
}

