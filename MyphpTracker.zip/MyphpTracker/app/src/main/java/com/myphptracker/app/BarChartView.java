package com.myphptracker.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import java.util.HashMap;
import java.util.Map;

public class BarChartView extends View {

    private HashMap<String, Float> data = new HashMap<>();
    private Paint barPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint textPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int[] colors = {
        Color.parseColor("#2196F3"),
        Color.parseColor("#4CAF50"),
        Color.parseColor("#F44336"),
        Color.parseColor("#FF9800"),
        Color.parseColor("#9C27B0"),
        Color.parseColor("#00BCD4"),
        Color.parseColor("#795548")
    };

    public BarChartView(Context context) {
        super(context);
        init();
    }

    public BarChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    void init() {
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(28f);
        textPaint.setTextAlign(Paint.Align.CENTER);

        labelPaint.setColor(Color.parseColor("#263238"));
        labelPaint.setTextSize(24f);
        labelPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setData(HashMap<String, Float> d) {
        data = d;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (data == null || data.isEmpty()) {
            labelPaint.setColor(Color.GRAY);
            canvas.drawText("No data yet",
							getWidth() / 2f, getHeight() / 2f, labelPaint);
            return;
        }

        float maxVal = 0;
        for (float v : data.values()) {
            if (v > maxVal) maxVal = v;
        }

        int count   = data.size();
        float w     = getWidth();
        float h     = getHeight();
        float barW  = (w - 40) / count - 10;
        float startX= 20;
        int colorIdx= 0;

        for (Map.Entry<String, Float> entry : data.entrySet()) {
            float barH  = maxVal > 0
                ? ((entry.getValue() / maxVal) * (h - 50)) : 0;
            float left  = startX;
            float top   = h - barH - 30;
            float right = startX + barW;
            float bottom= h - 30;

            barPaint.setColor(colors[colorIdx % colors.length]);
            canvas.drawRect(new RectF(left, top, right, bottom), barPaint);

            // Label
            String label = entry.getKey();
            if (label.length() > 5) label = label.substring(0, 5);
            canvas.drawText(label, left + barW / 2, h - 8, labelPaint);

            startX += barW + 10;
            colorIdx++;
        }
    }
}

