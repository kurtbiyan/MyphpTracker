package com.myphptracker.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends Activity {

    // Views
    TextView tvBalance, tvIncome, tvExpense;
    TextView tvBudgetStatus, tvBudgetTap, tvTransactionLabel;
    ProgressBar progressBudget;
    ListView listTransactions;
    LinearLayout btnAdd, rootLayout, headerLayout;
    LinearLayout balanceCard, incomeCard, expenseCard, budgetCard;
    ImageView btnMenu;
    HorizontalScrollView filterScrollView;

    // Filter tabs
    TextView tabAll, tabToday, tabWeek, tabMonth, tabIncomeTab, tabExpenseTab;
    String currentFilter = "all";

    // Data
    ArrayList<String[]> transactions = new ArrayList<>();
    double totalIncome = 0, totalExpense = 0;
    double budgetLimit = 0;
    boolean isDarkMode = false;

    // Keys
    static final String PREFS      = "MoneyTrackerPrefs";
    static final String KEY_COUNT  = "count";
    static final String KEY_DESC   = "desc_";
    static final String KEY_AMT    = "amt_";
    static final String KEY_TYPE   = "type_";
    static final String KEY_DATE   = "date_";
    static final String KEY_CAT    = "cat_";
    static final String KEY_BUDGET = "budget";
    static final String KEY_DARK   = "darkmode";

    SharedPreferences prefs;

    String[] incomeCategories  = {
        "Salary","Freelance","Business","Investment","Gift","Other"
    };
    String[] expenseCategories = {
        "Food","Transport","Bills","Shopping",
        "Health","Entertainment","Education","Other"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActionBar() != null) getActionBar().hide();
        setContentView(R.layout.main);

        // Bind views
        tvBalance          = (TextView)             findViewById(R.id.tvBalance);
        tvIncome           = (TextView)             findViewById(R.id.tvIncome);
        tvExpense          = (TextView)             findViewById(R.id.tvExpense);
        tvBudgetStatus     = (TextView)             findViewById(R.id.tvBudgetStatus);
        tvBudgetTap        = (TextView)             findViewById(R.id.tvBudgetTap);
        tvTransactionLabel = (TextView)             findViewById(R.id.tvTransactionLabel);
        progressBudget     = (ProgressBar)          findViewById(R.id.progressBudget);
        listTransactions   = (ListView)             findViewById(R.id.listTransactions);
        btnAdd             = (LinearLayout)         findViewById(R.id.btnAdd);
        btnMenu            = (ImageView)            findViewById(R.id.btnMenu);
        rootLayout         = (LinearLayout)         findViewById(R.id.rootLayout);
        headerLayout       = (LinearLayout)         findViewById(R.id.headerLayout);
        balanceCard        = (LinearLayout)         findViewById(R.id.balanceCard);
        incomeCard         = (LinearLayout)         findViewById(R.id.incomeCard);
        expenseCard        = (LinearLayout)         findViewById(R.id.expenseCard);
        budgetCard         = (LinearLayout)         findViewById(R.id.budgetCard);
        filterScrollView   = (HorizontalScrollView) findViewById(R.id.filterScrollView);

        tabAll        = (TextView) findViewById(R.id.tabAll);
        tabToday      = (TextView) findViewById(R.id.tabToday);
        tabWeek       = (TextView) findViewById(R.id.tabWeek);
        tabMonth      = (TextView) findViewById(R.id.tabMonth);
        tabIncomeTab  = (TextView) findViewById(R.id.tabIncome);
        tabExpenseTab = (TextView) findViewById(R.id.tabExpense);

        prefs       = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        budgetLimit = Double.parseDouble(prefs.getString(KEY_BUDGET, "0"));
        isDarkMode  = prefs.getBoolean(KEY_DARK, false);

        loadData();
        applyTheme();
        updateSummary();
        setupFilterTabs();

        // Hamburger menu
        btnMenu.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { showHamburgerMenu(); }
			});

        // Budget tap
        tvBudgetTap.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { showBudgetDialog(); }
			});
        tvBudgetStatus.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { showBudgetDialog(); }
			});

        // Add transaction
        btnAdd.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { showAddDialog(); }
			});

        // Tap to edit
        listTransactions.setOnItemClickListener(
            new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent,
										View view, int position, long id) {
                    ArrayList<String[]> filtered = getFilteredList();
                    showEditDialog(filtered.get(position));
                }
            });

        // Long press to delete
        listTransactions.setOnItemLongClickListener(
            new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent,
											   View view, final int position, long id) {
                    final ArrayList<String[]> filtered = getFilteredList();
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete Transaction")
                        .setMessage("Remove this entry?")
                        .setPositiveButton("Delete",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface d, int w) {
								String[] t = filtered.get(position);
								double amt = Double.parseDouble(t[1]);
								if (t[2].equals("income")) totalIncome -= amt;
								else totalExpense -= amt;
								transactions.remove(t);
								saveData();
								updateSummary();
								Toast.makeText(MainActivity.this,
											   "Transaction deleted",
											   Toast.LENGTH_SHORT).show();
							}
						})
                        .setNegativeButton("Cancel", null)
                        .show();
                    return true;
                }
            });
    }

    // ── Hamburger Menu ─────────────────────────────────────────
    void showHamburgerMenu() {
        String darkLabel = isDarkMode ? "Light Mode" : "Dark Mode";

        String[] menuItems = {
            darkLabel,
            "View Charts",
            "Export CSV",
            "Set Budget"
        };

        new AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(menuItems, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which) {
                        case 0: toggleDarkMode();  break;
                        case 1: showChartDialog(); break;
                        case 2: exportToCSV();     break;
                        case 3: showBudgetDialog();break;
                    }
                }
            })
            .setNegativeButton("Close", null)
            .show();
    }

    // ── Dark Mode ──────────────────────────────────────────────
    void toggleDarkMode() {
        isDarkMode = !isDarkMode;
        prefs.edit().putBoolean(KEY_DARK, isDarkMode).apply();
        applyTheme();
        updateSummary();
        Toast.makeText(this,
					   isDarkMode ? "Dark mode enabled" : "Light mode enabled",
					   Toast.LENGTH_SHORT).show();
    }

    void applyTheme() {
        if (isDarkMode) {
            rootLayout.setBackgroundColor(Color.parseColor("#121212"));
            headerLayout.setBackgroundColor(Color.parseColor("#1E1E1E"));
            balanceCard.setBackgroundColor(Color.parseColor("#2C2C2C"));
            incomeCard.setBackgroundColor(Color.parseColor("#2C2C2C"));
            expenseCard.setBackgroundColor(Color.parseColor("#2C2C2C"));
            budgetCard.setBackgroundColor(Color.parseColor("#2C2C2C"));
            filterScrollView.setBackgroundColor(Color.parseColor("#1E1E1E"));
            tvTransactionLabel.setBackgroundColor(Color.parseColor("#121212"));
            tvTransactionLabel.setTextColor(Color.WHITE);
            btnAdd.setBackgroundColor(Color.parseColor("#1565C0"));
        } else {
            rootLayout.setBackgroundColor(Color.parseColor("#F0F4F8"));
            headerLayout.setBackgroundColor(Color.parseColor("#2196F3"));
            balanceCard.setBackgroundColor(Color.parseColor("#1976D2"));
            incomeCard.setBackgroundColor(Color.parseColor("#1565C0"));
            expenseCard.setBackgroundColor(Color.parseColor("#1565C0"));
            budgetCard.setBackgroundColor(Color.parseColor("#1565C0"));
            filterScrollView.setBackgroundColor(Color.parseColor("#E3F2FD"));
            tvTransactionLabel.setBackgroundColor(Color.parseColor("#F0F4F8"));
            tvTransactionLabel.setTextColor(Color.parseColor("#37474F"));
            btnAdd.setBackgroundColor(Color.parseColor("#2196F3"));
        }
    }

    // ── Filter Tabs ────────────────────────────────────────────
    void setupFilterTabs() {
        View.OnClickListener tabClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTabColors();
                v.setBackgroundColor(Color.parseColor("#2196F3"));
                ((TextView) v).setTextColor(Color.WHITE);

                int vid = v.getId();
                if      (vid == R.id.tabAll)     currentFilter = "all";
                else if (vid == R.id.tabToday)   currentFilter = "today";
                else if (vid == R.id.tabWeek)    currentFilter = "week";
                else if (vid == R.id.tabMonth)   currentFilter = "month";
                else if (vid == R.id.tabIncome)  currentFilter = "income";
                else if (vid == R.id.tabExpense) currentFilter = "expense";

                updateList();
            }
        };

        tabAll.setOnClickListener(tabClick);
        tabToday.setOnClickListener(tabClick);
        tabWeek.setOnClickListener(tabClick);
        tabMonth.setOnClickListener(tabClick);
        tabIncomeTab.setOnClickListener(tabClick);
        tabExpenseTab.setOnClickListener(tabClick);
    }

    void resetTabColors() {
        TextView[] tabs = {tabAll, tabToday, tabWeek,
			tabMonth, tabIncomeTab, tabExpenseTab};
        for (TextView t : tabs) {
            t.setBackgroundColor(isDarkMode
								 ? Color.parseColor("#2C2C2C")
								 : Color.WHITE);
            t.setTextColor(Color.parseColor("#2196F3"));
        }
    }

    // ── Get Filtered List ──────────────────────────────────────
    ArrayList<String[]> getFilteredList() {
        ArrayList<String[]> result = new ArrayList<>();
        Calendar cal = Calendar.getInstance();

        for (String[] t : transactions) {
            if (currentFilter.equals("all")) {
                result.add(t);
            } else if (currentFilter.equals("income")) {
                if (t[2].equals("income")) result.add(t);
            } else if (currentFilter.equals("expense")) {
                if (t[2].equals("expense")) result.add(t);
            } else {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat(
                        "MMM dd, yyyy HH:mm", Locale.getDefault());
                    Date tDate = sdf.parse(t[3]);
                    Calendar tCal = Calendar.getInstance();
                    tCal.setTime(tDate);

                    if (currentFilter.equals("today")) {
                        if (tCal.get(Calendar.DAY_OF_YEAR)
							== cal.get(Calendar.DAY_OF_YEAR)
                            && tCal.get(Calendar.YEAR)
							== cal.get(Calendar.YEAR))
                            result.add(t);
                    } else if (currentFilter.equals("week")) {
                        if (tCal.get(Calendar.WEEK_OF_YEAR)
							== cal.get(Calendar.WEEK_OF_YEAR)
                            && tCal.get(Calendar.YEAR)
							== cal.get(Calendar.YEAR))
                            result.add(t);
                    } else if (currentFilter.equals("month")) {
                        if (tCal.get(Calendar.MONTH)
							== cal.get(Calendar.MONTH)
                            && tCal.get(Calendar.YEAR)
							== cal.get(Calendar.YEAR))
                            result.add(t);
                    }
                } catch (Exception e) {
                    result.add(t);
                }
            }
        }
        return result;
    }

    // ── Add Dialog ─────────────────────────────────────────────
    void showAddDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dv = inflater.inflate(R.layout.dialog_add_transaction, null);

        final EditText etDesc    = (EditText)   dv.findViewById(R.id.etDescription);
        final EditText etAmount  = (EditText)   dv.findViewById(R.id.etAmount);
        final RadioGroup rgType  = (RadioGroup) dv.findViewById(R.id.rgType);
        final Spinner spCategory = (Spinner)    dv.findViewById(R.id.spinnerCategory);

        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, incomeCategories);
        catAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(catAdapter);

        rgType.setOnCheckedChangeListener(
            new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    String[] cats = (checkedId == R.id.rbIncome)
                        ? incomeCategories : expenseCategories;
                    ArrayAdapter<String> a = new ArrayAdapter<>(
                        MainActivity.this,
                        android.R.layout.simple_spinner_item, cats);
                    a.setDropDownViewResource(
                        android.R.layout.simple_spinner_dropdown_item);
                    spCategory.setAdapter(a);
                }
            });

        new AlertDialog.Builder(this)
            .setView(dv)
            .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String desc   = etDesc.getText().toString().trim();
                    String amtStr = etAmount.getText().toString().trim();
                    String cat    = spCategory.getSelectedItem().toString();

                    if (desc.isEmpty() || amtStr.isEmpty()) {
                        Toast.makeText(MainActivity.this,
									   "Please fill all fields!",
									   Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double amount;
                    try {
                        amount = Double.parseDouble(amtStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(MainActivity.this,
									   "Invalid amount!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int selId = rgType.getCheckedRadioButtonId();
                    String type = (selId == R.id.rbIncome)
                        ? "income" : "expense";
                    String date = new SimpleDateFormat(
                        "MMM dd, yyyy HH:mm",
                        Locale.getDefault()).format(new Date());

                    if (type.equals("income")) totalIncome += amount;
                    else totalExpense += amount;

                    transactions.add(0,
									 new String[]{desc, amtStr, type, date, cat});
                    saveData();
                    updateSummary();

                    if (budgetLimit > 0
						&& totalExpense >= budgetLimit * 0.9) {
                        Toast.makeText(MainActivity.this,
									   "Warning: Near budget limit!",
									   Toast.LENGTH_LONG).show();
                    }
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // ── Edit Dialog ────────────────────────────────────────────
    void showEditDialog(final String[] transaction) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dv = inflater.inflate(R.layout.dialog_edit_transaction, null);

        final EditText etDesc    = (EditText)   dv.findViewById(R.id.etEditDescription);
        final EditText etAmount  = (EditText)   dv.findViewById(R.id.etEditAmount);
        final RadioGroup rgType  = (RadioGroup) dv.findViewById(R.id.rgEditType);
        final Spinner spCategory = (Spinner)    dv.findViewById(R.id.spinnerEditCategory);

        etDesc.setText(transaction[0]);
        etAmount.setText(transaction[1]);

        boolean isIncome = transaction[2].equals("income");
        String[] cats = isIncome ? incomeCategories : expenseCategories;

        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, cats);
        catAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(catAdapter);

        if (transaction.length > 4) {
            for (int i = 0; i < cats.length; i++) {
                if (cats[i].equals(transaction[4])) {
                    spCategory.setSelection(i);
                    break;
                }
            }
        }

        if (isIncome) rgType.check(R.id.rbEditIncome);
        else          rgType.check(R.id.rbEditExpense);

        rgType.setOnCheckedChangeListener(
            new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    String[] c = (checkedId == R.id.rbEditIncome)
                        ? incomeCategories : expenseCategories;
                    ArrayAdapter<String> a = new ArrayAdapter<>(
                        MainActivity.this,
                        android.R.layout.simple_spinner_item, c);
                    a.setDropDownViewResource(
                        android.R.layout.simple_spinner_dropdown_item);
                    spCategory.setAdapter(a);
                }
            });

        new AlertDialog.Builder(this)
            .setTitle("Edit Transaction")
            .setView(dv)
            .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String newDesc   = etDesc.getText().toString().trim();
                    String newAmtStr = etAmount.getText().toString().trim();
                    String newCat    = spCategory.getSelectedItem().toString();

                    if (newDesc.isEmpty() || newAmtStr.isEmpty()) {
                        Toast.makeText(MainActivity.this,
									   "Please fill all fields!",
									   Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double newAmount;
                    try {
                        newAmount = Double.parseDouble(newAmtStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(MainActivity.this,
									   "Invalid amount!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int selId = rgType.getCheckedRadioButtonId();
                    String newType = (selId == R.id.rbEditIncome)
                        ? "income" : "expense";

                    // Reverse old
                    double oldAmt = Double.parseDouble(transaction[1]);
                    if (transaction[2].equals("income")) totalIncome -= oldAmt;
                    else totalExpense -= oldAmt;

                    // Apply new
                    if (newType.equals("income")) totalIncome += newAmount;
                    else totalExpense += newAmount;

                    transaction[0] = newDesc;
                    transaction[1] = newAmtStr;
                    transaction[2] = newType;
                    transaction[4] = newCat;

                    saveData();
                    updateSummary();
                    Toast.makeText(MainActivity.this,
								   "Transaction updated!",
								   Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // ── Budget Dialog ──────────────────────────────────────────
    void showBudgetDialog() {
        final EditText et = new EditText(this);
        et.setHint("Enter monthly budget limit");
        et.setInputType(
            android.text.InputType.TYPE_CLASS_NUMBER
            | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setPadding(40, 20, 40, 20);
        if (budgetLimit > 0) et.setText(String.valueOf((int)budgetLimit));

        new AlertDialog.Builder(this)
            .setTitle("Set Monthly Budget")
            .setView(et)
            .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    String val = et.getText().toString().trim();
                    if (!val.isEmpty()) {
                        try {
                            budgetLimit = Double.parseDouble(val);
                            prefs.edit()
                                .putString(KEY_BUDGET,
										   String.valueOf(budgetLimit))
                                .apply();
                            updateSummary();
                            Toast.makeText(MainActivity.this,
										   "Budget set to ₱" + (int)budgetLimit,
										   Toast.LENGTH_SHORT).show();
                        } catch (NumberFormatException e) {
                            Toast.makeText(MainActivity.this,
										   "Invalid amount!",
										   Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            })
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Clear", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    budgetLimit = 0;
                    prefs.edit().putString(KEY_BUDGET, "0").apply();
                    updateSummary();
                    Toast.makeText(MainActivity.this,
								   "Budget cleared!", Toast.LENGTH_SHORT).show();
                }
            })
            .show();
    }

    // ── Chart Dialog ───────────────────────────────────────────
    void showChartDialog() {
        // Calculate category totals
        HashMap<String, Float> catTotals = new HashMap<>();
        double maxTotal = 0;

        for (String[] t : transactions) {
            if (t[2].equals("expense")) {
                String cat   = t.length > 4 ? t[4] : "Other";
                float cur    = catTotals.containsKey(cat)
                    ? catTotals.get(cat) : 0f;
                float newVal = cur + Float.parseFloat(t[1]);
                catTotals.put(cat, newVal);
                if (newVal > maxTotal) maxTotal = newVal;
            }
        }

        if (catTotals.isEmpty()) {
            Toast.makeText(this,
						   "No expense data to display",
						   Toast.LENGTH_SHORT).show();
            return;
        }

        // Build category list
        final ArrayList<String[]> catList = new ArrayList<>();
        final double finalMax = maxTotal;

        for (HashMap.Entry<String, Float> e : catTotals.entrySet()) {
            catList.add(new String[]{
							e.getKey(),
							String.valueOf(e.getValue())
						});
        }

        // Sort by amount (highest first)
        java.util.Collections.sort(catList,
            new java.util.Comparator<String[]>() {
                @Override
                public int compare(String[] a, String[] b) {
                    float valA = Float.parseFloat(a[1]);
                    float valB = Float.parseFloat(b[1]);
                    return Float.compare(valB, valA);
                }
            });

        // Create list view
        ListView listCat = new ListView(this);
        listCat.setAdapter(new BaseAdapter() {
				@Override public int getCount() { return catList.size(); }
				@Override public Object getItem(int i) { return catList.get(i); }
				@Override public long getItemId(int i) { return i; }

				@Override
				public View getView(int pos, View cv, ViewGroup parent) {
					View row = LayoutInflater.from(MainActivity.this)
						.inflate(R.layout.item_category, parent, false);

					TextView tvName = (TextView) row.findViewById(R.id.tvCatName);
					TextView tvAmt  = (TextView) row.findViewById(R.id.tvCatAmount);
					ProgressBar pb  = (ProgressBar) row.findViewById(R.id.progressCat);

					String[] item = catList.get(pos);
					float val = Float.parseFloat(item[1]);

					tvName.setText(item[0]);
					tvAmt.setText(String.format("₱ %.2f", val));

					int pct = finalMax > 0
						? (int)((val / finalMax) * 100) : 0;
					pb.setProgress(pct);

					return row;
				}
			});

        new AlertDialog.Builder(this)
            .setTitle("Spending Overview")
            .setView(listCat)
            .setPositiveButton("Close", null)
            .show();
    }

    // ── Export CSV (Fixed - Without FileProvider) ─────────────
    void exportToCSV() {
        if (transactions.isEmpty()) {
            Toast.makeText(this,
						   "No transactions to export",
						   Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Use Downloads directory (publicly accessible)
            File downloadsDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS);

            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs();
            }

            String fileName = "MoneyTracker_"
                + new SimpleDateFormat("yyyyMMdd_HHmm",
									   Locale.getDefault()).format(new Date())
                + ".csv";

            final File file = new File(downloadsDir, fileName);

            // Write CSV
            FileWriter fw = new FileWriter(file);
            fw.append("Description,Amount,Type,Category,Date\n");

            for (String[] t : transactions) {
                fw.append("\"").append(t[0]).append("\",")
					.append(t[1]).append(",")
					.append(t[2]).append(",")
					.append(t.length > 4 ? t[4] : "Other").append(",")
					.append("\"").append(t[3]).append("\"\n");
            }
            fw.flush();
            fw.close();

            // Show success message with file location
            String message = "Exported to Downloads:\n" + fileName
                + "\n\nTotal: " + transactions.size() + " transactions"
                + "\nIncome: ₱" + String.format("%.2f", totalIncome)
                + "\nExpense: ₱" + String.format("%.2f", totalExpense);

            new AlertDialog.Builder(this)
                .setTitle("Export Successful")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .setNeutralButton("Open File", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(
                            Uri.fromFile(file), 
                            "text/csv");
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try {
                            startActivity(intent);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this,
										   "No app found to open CSV files",
										   Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .show();

        } catch (Exception e) {
            Toast.makeText(this,
						   "Export failed: " + e.getMessage(),
						   Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    // ── Save Data ──────────────────────────────────────────────
    void saveData() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_COUNT, transactions.size());
        for (int i = 0; i < transactions.size(); i++) {
            String[] t = transactions.get(i);
            editor.putString(KEY_DESC + i, t[0]);
            editor.putString(KEY_AMT  + i, t[1]);
            editor.putString(KEY_TYPE + i, t[2]);
            editor.putString(KEY_DATE + i, t[3]);
            editor.putString(KEY_CAT  + i, t.length > 4 ? t[4] : "Other");
        }
        editor.apply();
    }

    // ── Load Data ──────────────────────────────────────────────
    void loadData() {
        totalIncome  = 0;
        totalExpense = 0;
        transactions.clear();

        int count = prefs.getInt(KEY_COUNT, 0);
        for (int i = 0; i < count; i++) {
            String desc = prefs.getString(KEY_DESC + i, "");
            String amt  = prefs.getString(KEY_AMT  + i, "0");
            String type = prefs.getString(KEY_TYPE + i, "income");
            String date = prefs.getString(KEY_DATE + i, "");
            String cat  = prefs.getString(KEY_CAT  + i, "Other");
            transactions.add(new String[]{desc, amt, type, date, cat});
            double amount = Double.parseDouble(amt);
            if (type.equals("income")) totalIncome += amount;
            else totalExpense += amount;
        }
    }

    // ── Update Summary ─────────────────────────────────────────
    void updateSummary() {
        double balance = totalIncome - totalExpense;

        tvBalance.setText(String.format("₱ %.2f", balance));
        tvIncome.setText(String.format("₱ %.2f", totalIncome));
        tvExpense.setText(String.format("₱ %.2f", totalExpense));

        tvBalance.setTextColor(balance >= 0
							   ? Color.WHITE : Color.parseColor("#FF5252"));

        if (budgetLimit > 0) {
            int pct = (int)((totalExpense / budgetLimit) * 100);
            if (pct > 100) pct = 100;
            progressBudget.setProgress(pct);

            // NO $ SYMBOL - ONLY ₱
            tvBudgetStatus.setText(
                String.format("₱%.0f / ₱%.0f", totalExpense, budgetLimit));
            tvBudgetTap.setText("Tap to change budget");

            if (pct >= 100) {
                tvBudgetStatus.setTextColor(Color.parseColor("#FF5252"));
                tvBudgetTap.setText("Budget exceeded!");
                tvBudgetTap.setTextColor(Color.parseColor("#FF5252"));
            } else if (pct >= 90) {
                tvBudgetStatus.setTextColor(Color.parseColor("#FF9800"));
                tvBudgetTap.setText("Near budget limit!");
                tvBudgetTap.setTextColor(Color.parseColor("#FF9800"));
            } else {
                tvBudgetStatus.setTextColor(Color.WHITE);
                tvBudgetTap.setTextColor(Color.parseColor("#90CAF9"));
            }
        } else {
            progressBudget.setProgress(0);
            tvBudgetStatus.setText("Not Set");
            tvBudgetStatus.setTextColor(Color.WHITE);
            tvBudgetTap.setText("Tap to set budget limit");
            tvBudgetTap.setTextColor(Color.parseColor("#90CAF9"));
        }

        updateList();
    }

    // ── Update List ────────────────────────────────────────────
    void updateList() {
        ArrayList<String[]> filtered = getFilteredList();
        tvTransactionLabel.setText(
            "Transactions (" + filtered.size() + ")");
        listTransactions.setAdapter(
            new TransactionAdapter(this, filtered));
    }

    // ── Transaction Adapter ────────────────────────────────────
    class TransactionAdapter extends BaseAdapter {

        Context ctx;
        ArrayList<String[]> data;

        TransactionAdapter(Context c, ArrayList<String[]> d) {
            ctx  = c;
            data = d;
        }

        @Override public int    getCount()       { return data.size(); }
        @Override public Object getItem(int i)   { return data.get(i); }
        @Override public long   getItemId(int i) { return i; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = LayoutInflater.from(ctx)
                .inflate(R.layout.item_transaction, parent, false);

            ImageView ivType = (ImageView) row.findViewById(R.id.ivType);
            TextView  tvDesc = (TextView)  row.findViewById(R.id.tvDesc);
            TextView  tvCat  = (TextView)  row.findViewById(R.id.tvCategory);
            TextView  tvDate = (TextView)  row.findViewById(R.id.tvDate);
            TextView  tvAmt  = (TextView)  row.findViewById(R.id.tvAmt);

            String[] t        = data.get(position);
            boolean  isIncome = t[2].equals("income");

            ivType.setImageResource(isIncome
									? R.drawable.ic_income
									: R.drawable.ic_expense);

            tvDesc.setText(t[0]);
            tvDate.setText(t[3]);
            tvCat.setText(t.length > 4 ? t[4] : "Other");

            tvCat.setBackgroundColor(isIncome
									 ? Color.parseColor("#388E3C")
									 : Color.parseColor("#1976D2"));

            tvAmt.setText((isIncome ? "+ " : "- ") + "₱ " + t[1]);
            tvAmt.setTextColor(isIncome
							   ? Color.parseColor("#2E7D32")
							   : Color.parseColor("#C62828"));

            // Dark mode list styling
            if (isDarkMode) {
                row.setBackgroundColor(Color.parseColor("#1E1E1E"));
                tvDesc.setTextColor(Color.WHITE);
                tvDate.setTextColor(Color.parseColor("#B0B0B0"));
            } else {
                row.setBackgroundColor(Color.WHITE);
                tvDesc.setTextColor(Color.parseColor("#212121"));
                tvDate.setTextColor(Color.parseColor("#757575"));
            }

            return row;
        }
    }
}

